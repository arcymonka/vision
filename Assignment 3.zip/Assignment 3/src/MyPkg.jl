module MyPkg

greet() = print("Hello World!")

end # module MyPkg
